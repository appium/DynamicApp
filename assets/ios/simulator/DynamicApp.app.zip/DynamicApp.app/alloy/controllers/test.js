function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        Alloy.Globals.MainController.switchToWelcomeView();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "test";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.test = Ti.UI.createView({
        layout: "absolute",
        backgroundColor: "white",
        id: "test"
    });
    $.__views.test && $.addTopLevelView($.__views.test);
    $.__views.test_close = Ti.UI.createLabel({
        accessibilityLabel: "test_close",
        accessibilityValue: "Click to close!",
        bottom: 0,
        textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
        color: "#336699",
        font: {
            fontSize: 16
        },
        id: "test_close",
        text: "Click to close!"
    });
    $.__views.test.add($.__views.test_close);
    doClick ? $.__views.test_close.addEventListener("click", doClick) : __defers["$.__views.test_close!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    __defers["$.__views.test_close!click!doClick"] && $.__views.test_close.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;