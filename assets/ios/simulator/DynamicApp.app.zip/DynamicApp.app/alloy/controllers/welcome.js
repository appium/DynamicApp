function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        var url = Alloy.Globals.codeUrl;
        var client = Ti.Network.createHTTPClient({
            onload: function() {
                Ti.API.warn("Received text: " + this.responseText);
                var code = JSON.parse(this.responseText).code;
                Alloy.Globals.MainController.switchToTestView(code);
            },
            onerror: function(e) {
                Ti.API.debug(e.error);
                alert("error");
            },
            timeout: 5e3
        });
        client.open("GET", url);
        client.send();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "welcome";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.welcome = Ti.UI.createView({
        layout: "vertical",
        backgroundColor: "#d9fde7",
        id: "welcome"
    });
    $.__views.welcome && $.addTopLevelView($.__views.welcome);
    $.__views.welcome_start = Ti.UI.createLabel({
        accessibilityLabel: "welcome_start",
        top: "50%",
        textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
        color: "#336699",
        accessibilityValue: "Click to start!",
        id: "welcome_start",
        text: "Click to start!"
    });
    $.__views.welcome.add($.__views.welcome_start);
    doClick ? $.__views.welcome_start.addEventListener("click", doClick) : __defers["$.__views.welcome_start!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    __defers["$.__views.welcome_start!click!doClick"] && $.__views.welcome_start.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;