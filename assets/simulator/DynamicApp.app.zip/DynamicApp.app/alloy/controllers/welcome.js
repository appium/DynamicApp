function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        var url = $.url.value;
        var client = Ti.Network.createHTTPClient({
            onload: function() {
                Ti.API.warn("Received text: " + this.responseText);
                var code = JSON.parse(this.responseText).code;
                Alloy.Globals.MainController.switchToTestView(code);
            },
            onerror: function(e) {
                Ti.API.debug(e.error);
                alert("error");
            },
            timeout: 5e3
        });
        client.open("GET", url);
        client.send();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "welcome";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.welcome = Ti.UI.createView({
        layout: "vertical",
        backgroundColor: "cyan",
        id: "welcome"
    });
    $.__views.welcome && $.addTopLevelView($.__views.welcome);
    $.__views.url = Ti.UI.createTextField({
        accessibilityLabel: "url",
        top: "40%",
        color: "#000",
        borderColor: "#000",
        borderRadius: 5,
        borderWidth: 1,
        height: 18,
        paddingRight: 3,
        paddingLeft: 3,
        font: {
            fontSize: 12
        },
        id: "url",
        editable: "true",
        value: "1/ Enter url"
    });
    $.__views.welcome.add($.__views.url);
    $.__views.start = Ti.UI.createLabel({
        accessibilityLabel: "start",
        accessibilityValue: "2/ Click to start!",
        top: 10,
        textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
        color: "#336699",
        font: {
            fontSize: 12
        },
        id: "start",
        text: "2/ Click to start!"
    });
    $.__views.welcome.add($.__views.start);
    doClick ? $.__views.start.addEventListener("click", doClick) : __defers["$.__views.start!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    __defers["$.__views.start!click!doClick"] && $.__views.start.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;