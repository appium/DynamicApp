function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function clear() {
        if (activeView) {
            $.index.remove(activeView);
            activeView = null;
        }
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        var __parentSymbol = __processArg(arguments[0], "__parentSymbol");
        var $model = __processArg(arguments[0], "$model");
        var __itemTemplate = __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.index = Ti.UI.createWindow({
        layout: "vertical",
        backgroundColor: "white",
        id: "index"
    });
    $.__views.index && $.addTopLevelView($.__views.index);
    exports.destroy = function() {};
    _.extend($, $.__views);
    Alloy.Globals.MainController = $;
    var welcome = Alloy.createController("welcome");
    var test = Alloy.createController("test");
    var activeView;
    var switchToWelcomeView = function() {
        clear();
        $.index.add(welcome.getView());
        activeView = welcome.getView();
    };
    exports.switchToWelcomeView = switchToWelcomeView;
    exports.switchToTestView = function(code) {
        clear();
        var testView = test.getView();
        eval("var runCode = " + code + ";");
        runCode(testView);
        activeView = testView;
        $.index.add(testView);
    };
    switchToWelcomeView();
    $.index.open();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;